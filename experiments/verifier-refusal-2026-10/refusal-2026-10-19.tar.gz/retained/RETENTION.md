# Publication subset

All original measured inputs, drafts, source snapshots, runner, raw results and
review are byte-preserved. Argon's raw design transcript is not published.
RESULT-MANIFEST.json is the historical 66-entry inventory; its argon-design.json
entry is intentionally absent. Use PUBLICATION-MANIFEST.json for this subset.
The historical independent review covered the larger original inventory.
Argon helped design the cases; Codex/root executed them; codex/2497_final_review
reviewed retained results without executing the binary. Identities are declared.
Later PR review covers publication separately. No model transcript is required
to replay the measured inputs. Draft inputs are retained but were not executed.
