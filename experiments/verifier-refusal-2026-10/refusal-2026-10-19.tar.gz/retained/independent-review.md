# Independent retained-result review — READY

Reviewer: Codex `/root/2497_final_review` (`codex/2497_final_review`), 2026-10-19. I authored neither the plan, inputs nor implementation and did not execute the verifier. Argon advised; Codex/root constructed and executed. Identity and non-authorship are declared, not independently authenticated. Any later publisher is a relay, not this reviewer.

Bound RESULT-MANIFEST.json SHA256: `f44f5bf16cb1d99e7bd795ab5d23c98ed045829a41c8da9d25188da8a327d089`.
Bound REPORT.md SHA256: `ed492c43d8c23aa34132be3c7e87cdad1ce5f5438c03e365b9dc884d1793e4ba`.
Measured binary receipt: `f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703`, release source `098ebbeb2efe19c3b8fdc6bc41250c80169cc06c`; selected-source review attribution `89abccde9b0e3fa7219ecd746d025ca2b018f346`.

No actionable findings in the bounded report. READY supports this local retained result and its explicit limitations, not a publication, merge or issue-closure action.

## Independent checks

All 66 result-manifest entries match, as do all four preflight-manifest entries and selected retained source hashes in source-parity.json. The manifest is a named-file inventory, not a claim to cover every directory entry. Own script independent-recount.py performs read-only stdlib checks; independent-recount.json records results. The first script pass used the Rust field name content_hash; inspecting raw bytes identified the actual wire key assaycontenthash, and only the reviewer assertion was corrected.

Eight executed input sizes/digests match cases.json. Original bytes equal small.tar.gz. Decoded repacked positive has exactly the original manifest.json and events.ndjson bytes. Event-0 has 1,000 lines, unchanged lines 1–999, equal-width allow-to-block edit only on line 0, unchanged assaycontenthash and unchanged manifest. The manifest-hash case retains event bytes and changes exactly one hexadecimal character at the end of the expected events SHA256 while retaining sha256: and all other manifest fields. Missing-events retains only the original manifest. Gzip-CRC differs by one bit in the CRC field only, with unchanged raw-deflate-decoded tar bytes. Both header cases decode to exactly a single 512-byte valid tar header for manifest.json, with no member body; declared sizes are 10,485,760 and 10,485,761 respectively.

Independently recounted ten raw process receipts and stdout/stderr: original file/stdin and repacked file return 0 with success on stderr; event-0 file/stdin return 2 with IntegrityEventHash at seq 0; manifest-hash returns 2/IntegrityManifestHash; missing-events returns 2/ContractMissingFile; CRC returns 2/IntegrityGzip with Gzip trailer context; oversized header returns 2/LimitFileSize; exact-limit malformed header returns 2/ContractInvalidJson with EOF. All stdout is empty, no timeout is recorded. Three positive invocations and seven expected refusals, exactly as reported. Routes and input hashes match predeclared cases; no result records exist for the two removed position drafts or the prefix draft. Host receipt binds runner and case-manifest hashes.

Read run.py and construction scripts without executing them. Runner checks binary/input hashes, creates an exclusive results directory, retains each route's outputs, applies a 60-second timeout and output-file cap, and evaluates the declared oracle after capture. Source inspection supports the distinctions: default manifest ceiling is 10 MiB; declared-size guard uses strict greater-than before manifest materialization; event hash comparison precedes aggregate events-file hash comparison; missing-events and gzip trailer drain have separate typed codes. File/stdin CLI branches call the same verifier. Source files match retained parity hashes; the report's two-commit equality assertion is coordinator-provided provenance, not independently fetched Git or source-to-binary proof here.

## Limits

The result proves these selected constructed cases and exact observed diagnostic oracles for the pinned binary. It does not authenticate hostile origin, estimate global accuracy/false-positive/false-negative rates, demonstrate a mutation score, or prove resistance to fully recomputed internally consistent bundles. Header boundary evidence distinguishes preflight rejection from a downstream malformed-input failure, not valid 10 MiB acceptance or measured memory/RSS protection. First-failure interpretation is supported by source and diagnostics, not an instrumented trace.

Draft inputs are retained but unexecuted; predeclaration/no-retry chronology is supplied execution provenance, not independently authenticated history. This was coordinator execution in the existing VM, not a fresh clean-host or independently operated recipient run. No binaries, VM, builds or network were used by this reviewer. No frozen files were edited. #2494 remains open. The report's suggested next step is future work, not a plan authored by this reviewer.
