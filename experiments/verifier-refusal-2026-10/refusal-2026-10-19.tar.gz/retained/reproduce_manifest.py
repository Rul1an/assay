from pathlib import Path
import tarfile,io,gzip,copy,json
p=Path(__file__).resolve().parent
with tarfile.open(p/'small.tar.gz') as t:entries=[(m,t.extractfile(m).read()) for m in t.getmembers()]
b=next(b for m,b in entries if m.name=='manifest.json');h=json.loads(b)['files']['events.ndjson']['sha256'];new=h[:-1]+('0' if h[-1]!='0' else '1')
assert b.count(h.encode())==1;modified=b.replace(h.encode(),new.encode());assert len(modified)==len(b)
o=io.BytesIO()
with tarfile.open(fileobj=o,mode='w',format=tarfile.USTAR_FORMAT) as t:
 for old,data in entries:
  m=copy.copy(old);data=modified if m.name=='manifest.json' else data;m.size=len(data);t.addfile(m,io.BytesIO(data))
assert gzip.compress(o.getvalue(),mtime=0)==(p/'inputs/manifest-hash.tar.gz').read_bytes()
print('Manifest hash fixture reproduces on this host/Python build')
