from pathlib import Path
import json,hashlib,tarfile,gzip,io,zlib
P=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((P/'RESULT-MANIFEST.json').read_text());assert h((P/'RESULT-MANIFEST.json').read_bytes())=='f44f5bf16cb1d99e7bd795ab5d23c98ed045829a41c8da9d25188da8a327d089'
for n,d in manifest.items():assert h((P/n).read_bytes())==d,n
for n,d in json.loads((P/'PREFLIGHT-MANIFEST.json').read_text()).items():
 if isinstance(d,str) and len(d)==64: assert h((P/n).read_bytes())==d,n
for n,d in json.loads((P/'source-parity.json').read_text()).items():assert h((P/'source'/Path(n).name).read_bytes())==d
cases=json.loads((P/'cases.json').read_text());assert len(cases)==8
raw={c['name']:(P/'inputs'/(c['name']+'.tar.gz')).read_bytes() for c in cases}
for c in cases:assert len(raw[c['name']])==c['bytes'] and h(raw[c['name']])==c['sha256']
def decode(b):
 with tarfile.open(fileobj=io.BytesIO(b)) as t:
  ms=t.getmembers();assert len({m.name for m in ms})==len(ms) and all(m.isfile() for m in ms)
  return {m.name:t.extractfile(m).read() for m in ms}
a=decode(raw['original']);assert raw['original']==(P/'small.tar.gz').read_bytes();assert decode(raw['repacked'])==a
assert set(a)=={'manifest.json','events.ndjson'}
e=decode(raw['event-0']);assert e['manifest.json']==a['manifest.json'];old=a['events.ndjson'].splitlines(keepends=True);new=e['events.ndjson'].splitlines(keepends=True)
assert len(old)==len(new)==1000 and old[1:]==new[1:] and len(old[0])==len(new[0]);assert old[0].replace(b'"decision":"allow"',b'"decision":"block"')==new[0];assert json.loads(old[0])['assaycontenthash']==json.loads(new[0])['assaycontenthash']
m=decode(raw['manifest-hash']);assert m['events.ndjson']==a['events.ndjson'];before=json.loads(a['manifest.json']);after=json.loads(m['manifest.json']);orig=before['files']['events.ndjson']['sha256'];changed=after['files']['events.ndjson']['sha256'];assert orig[:-1]==changed[:-1] and orig[-1]!=changed[-1] and changed.startswith('sha256:');after['files']['events.ndjson']['sha256']=orig;assert after==before;assert sum(x!=y for x,y in zip(m['manifest.json'],a['manifest.json']))==1
assert decode(raw['missing-events'])=={'manifest.json':a['manifest.json']}
crc=raw['gzip-crc'];assert len(crc)==len(raw['original']) and sum((x^y).bit_count() for x,y in zip(crc,raw['original']))==1 and crc[:-8]==raw['original'][:-8] and crc[-7:]==raw['original'][-7:]
assert zlib.decompress(crc[10:-8],-15)==gzip.decompress(raw['original'])
for size in [10485760,10485761]:
 header=gzip.decompress(raw['header-'+str(size)]);assert len(header)==512
 member=tarfile.TarInfo.frombuf(header,'utf-8','strict');assert member.name=='manifest.json' and member.size==size and member.isfile()
rows=[];success=0;refused=0
for c in cases:
 for route in c['routes']:
  name=c['name']+'-'+route;v=json.loads((P/'results'/(name+'.json')).read_text());err=(P/'results'/(name+'.stderr')).read_text();assert (P/'results'/(name+'.stdout')).read_bytes()==b''
  assert v['input_sha256']==c['sha256'] and v['expected']==c['expected'] and v['route']==route and v['case']==c['name'] and not v['timeout'] and v['oracle_match']
  assert v['argv'][-1]=='-' if route=='stdin' else v['argv'][-1].endswith('/'+c['name']+'.tar.gz')
  if c['expected']=='accept': assert v['exit']==0 and 'OK' in err;success+=1
  else:
   code=c['expected'].split(':')[0];assert v['exit']==2 and '('+code+')' in err;refused+=1
   if c['name']=='event-0':assert 'Content hash mismatch at seq 0' in err
   if c['name']=='header-10485760':assert 'EOF' in err
   if c['name']=='gzip-crc':assert 'Gzip trailer' in err
  rows.append({'name':name,'exit':v['exit'],'stderr':err})
assert len(rows)==10 and success==3 and refused==7
assert len([x for x in (P/'results').glob('*.json') if x.name not in ['host.json','complete.json']])==10
host=json.loads((P/'results/host.json').read_text());assert host['runner_sha256']==h((P/'run.py').read_bytes()) and host['case_manifest_sha256']==h((P/'cases.json').read_bytes())
out={'manifest_sha256':h((P/'RESULT-MANIFEST.json').read_bytes()),'manifest_entries':len(manifest),'input_count':len(cases),'invocations':len(rows),'successful':success,'expected_refusals':refused,'structural_checks':'PASS','results':rows,'host_receipt':host}
(P/'independent-recount.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['results','host_receipt']},indent=2))
