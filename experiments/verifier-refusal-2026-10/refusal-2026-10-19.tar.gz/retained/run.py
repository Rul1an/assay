import pathlib,json,hashlib,subprocess,resource,time,platform
root=pathlib.Path(__file__).resolve().parent
binary=pathlib.Path('/home/ubuntu/package/replay/release/assay-v6.14.1-aarch64-unknown-linux-gnu/assay')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)=='f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703'
cases=json.loads((root/'cases.json').read_text())
for c in cases:assert sha(root/'inputs'/(c['name']+'.tar.gz'))==c['sha256']
out=root/'results';out.mkdir()
(out/'host.json').write_text(json.dumps({'platform':platform.platform(),'binary_sha256':sha(binary),'runner_sha256':sha(pathlib.Path(__file__)),'case_manifest_sha256':sha(root/'cases.json'),'started_epoch':time.time()},indent=2))
def cap():resource.setrlimit(resource.RLIMIT_FSIZE,(65536,65536))
rows=[]
for c in cases:
 for route in c['routes']:
  path=root/'inputs'/(c['name']+'.tar.gz');prefix=out/(c['name']+'-'+route)
  argv=[str(binary),'--color','never','evidence','verify',str(path) if route=='file' else '-']
  start=time.time();timed_out=False
  with path.open('rb') as inp,prefix.with_suffix('.stdout').open('xb') as so,prefix.with_suffix('.stderr').open('xb') as se:
   try:r=subprocess.run(argv,stdin=inp if route=='stdin' else subprocess.DEVNULL,stdout=so,stderr=se,timeout=60,preexec_fn=cap);code=r.returncode
   except subprocess.TimeoutExpired:code=None;timed_out=True
  stdout=prefix.with_suffix('.stdout').read_text();stderr=prefix.with_suffix('.stderr').read_text();want=c['expected']
  if want=='accept':ok=code==0 and 'OK' in stderr and not stdout
  elif want.startswith('IntegrityEventHash:'):ok=code==2 and '(IntegrityEventHash)' in stderr and ('Content hash mismatch at '+want.split(':',1)[1]) in stderr and not stdout
  elif want=='not-LimitFileSize':ok=code==2 and 'LimitFileSize' not in stderr and not stdout
  else:ok=code==2 and '('+want+')' in stderr and not stdout
  row={'case':c['name'],'route':route,'argv':argv,'input_sha256':c['sha256'],'expected':want,'exit':code,'timeout':timed_out,'started_epoch':start,'oracle_match':ok}
  prefix.with_suffix('.json').write_text(json.dumps(row,indent=2));rows.append(row)
(out/'complete.json').write_text(json.dumps({'invocations':len(rows),'matched':sum(r['oracle_match'] for r in rows),'mismatches':[r for r in rows if not r['oracle_match']]},indent=2))
raise SystemExit(0 if all(r['oracle_match'] for r in rows) else 1)
