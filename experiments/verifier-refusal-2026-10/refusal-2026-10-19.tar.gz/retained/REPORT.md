# Bounded bundle-refusal pilot — 2026-10-19

One Linux execution of eight file cases and two stdin controls against the unchanged published Assay6.14.1 aarch64 GNU binary, SHA256 f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703, release source098ebbeb2efe19c3b8fdc6bc41250c80169cc06c. Source review at main89abccde9b0e3fa7219ecd746d025ca2b018f346; selected verifier/default-limit/CLI files are byte-identical between those commits (source-parity.json). No source build or product change.

Argon (gemini-4-argon-high via Cursor CLI, session1b1c3ddf-12b5-495a-ac0e-20b34c81fbc0) read source and advised the smaller case matrix. Codex/root constructed/froze inputs and executed on the previously provisioned Ubuntu24.04 aarch64 VM. This is not a new clean-host or independently operated recipient run. Initial9-case draft, removed position mutations and corrected unexecuted manifest-prefix draft remain retained. cases.json and PREFLIGHT-MANIFEST.json define the executed predeclared matrix; no retry or changed post-result oracle.

| Input and route | Result | Reached check |
|---|---|---|
| Original file / stdin; compliant repack file | 3 exits0 | Full bundle verification succeeds |
| Same-width event0 mutation, file / stdin | 2 exits2 | IntegrityEventHash at seq0 |
| Manifest expected-hash hexadecimal edit | exit2 | IntegrityManifestHash |
| Missing events member | exit2 | ContractMissingFile |
| One-bit gzip CRC corruption | exit2 | IntegrityGzip, Gzip trailer |
| Declared manifest size10MiB+1, absent body | exit2 | LimitFileSize |
| Declared manifest size10MiB, absent body | exit2 | ContractInvalidJson, downstream EOF |

All ten expectations matched; all stdout empty; no timeout. Eight distinct inputs, ten invocations, three successful positive invocations and seven expected refusals (one is the malformed at-limit boundary control). These finite selected cases are not a population false-positive/false-negative estimate, mutation score, detector accuracy or exhaustive coverage. Rendered diagnostic codes/reasons are measurement oracles for the pinned binary, not a newly frozen CLI contract.

The size case proves declared-member preflight and its strict boundary, not low memory use during source buffering/decompression, and the at-limit malformed case is not valid-input acceptance at10MiB. The verifier is unsigned internal-consistency checking: these findings do not establish authenticity, resistance to a fully recomputed bundle, provider outcomes, signature validity or safety. Event content, manifest content and gzip checksum checks remain separate. Source-level first-failure ordering plus exact diagnostics support which check fired; no instrumented execution trace was captured.

Original measured fixture bytes are retained as small.tar.gz; eight executed input hashes and raw process JSON/stdout/stderr remain alongside the scripts. regenerate.py reproduces the original candidate series in an exclusive directory; reproduce_manifest.py checks the later manifest-hash construction. Python/gzip implementation differences may change outer archive bytes on another host, so retained measured bytes remain the execution reference.

Smallest next step: publish a compact case/receipt package with these bounded claims after independent result review. Do not add a new framework or runtime feature. #2494 stays open for broader workloads, authentic signed-attestation cases, resource measurements and justified quality denominators. No PR, merge, release or public post is implied by this local pilot.
