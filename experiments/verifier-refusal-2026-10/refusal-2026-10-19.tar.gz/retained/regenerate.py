"""Reproduce candidate bytes in a fresh regenerated/ directory; never overwrite originals."""
from pathlib import Path
import tarfile,gzip,io,hashlib,copy
root=Path(__file__).resolve().parent
out=root/'regenerated';out.mkdir()
a=(root/'small.tar.gz').read_bytes()
assert hashlib.sha256(a).hexdigest()=='1dad40e26beaf02d0f6af60d415814ac159b8f73bbb246687ec4bc0229bab1be'
with tarfile.open(fileobj=io.BytesIO(a)) as t:members=[(m,t.extractfile(m).read()) for m in t.getmembers()]
ev=next(b for m,b in members if m.name=='events.ndjson');lines=ev.splitlines(keepends=True)
assert len(lines)==1000
def save(n,b):(out/(n+'.tar.gz')).write_bytes(b)
def repack(entries):
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w',format=tarfile.USTAR_FORMAT) as t:
  for old,data in entries:
   m=copy.copy(old);m.size=len(data);t.addfile(m,io.BytesIO(data))
 return gzip.compress(b.getvalue(),mtime=0)
save('original',a);save('repacked',repack(members))
for i in [0,500,999]:
 ll=lines.copy();assert ll[i].count(b'"decision":"allow"')==1
 ll[i]=ll[i].replace(b'"decision":"allow"',b'"decision":"block"');new=b''.join(ll);assert len(new)==len(ev)
 save(f'event-{i}',repack([(m,new if m.name=='events.ndjson' else b) for m,b in members]))
save('missing-events',repack([(m,b) for m,b in members if m.name=='manifest.json']))
b=bytearray(a);b[-8]^=1;save('gzip-crc',bytes(b))
for n in [10*1024*1024,10*1024*1024+1]:
 m=tarfile.TarInfo('manifest.json');m.size=n;m.mode=0o644
 save('header-'+str(n),gzip.compress(m.tobuf(format=tarfile.USTAR_FORMAT),mtime=0))
for p in out.iterdir():
 assert p.read_bytes()==(root/'inputs'/p.name).read_bytes(),p.name
print('All nine generated input archives match on this host/Python build')
