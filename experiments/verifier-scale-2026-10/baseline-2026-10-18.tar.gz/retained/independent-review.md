# Independent retained-package review — READY

Actual reviewer: codex/603_boundary. Builder/coordinator: codex/root. Any publisher is a separate relay identity. Identity and independence are self-declarations, not authenticated facts. I authored neither this method, measurement script, package preparation helper, comparison nor instructions. Earlier baseline recipient review was read-only and is preserved in baseline/; it did not author the governing method or implementation.

Reviewed frozen package manifest SHA256 `31f4f76e3b83e373d5f0ac8b0698998acc48a09002b79e65463d7d5819568c58` (242 entries). Performance source `098ebbeb2efe19c3b8fdc6bc41250c80169cc06c`; generator base `63f3ee6f5d8b3eb1d48e91912598d64aaff3eeb2` plus retained adapter. Review used local stdlib checks only; no build, benchmark, network or publication.

## Integrity, inputs and controls

Independently hashed all 242 manifest entries. All original 136 baseline-manifest entries match both the retained baseline and the original reviewed directory; its manifest, prior independent review and recount are byte-identical. This preserves the first failed control, original successful window, release/source artifacts and prior review without rewriting history.

Window2 run_linux_v2.py and inputs.json are byte-identical to baseline/run_linux_v2.py, baseline/inputs-v2.json and the first successful window's corresponding files. All five input-map entries match the fixtures/script and release executable. Release archive SHA256 is `972efe039ca474573c8d8b237e91c59776ab3a8f5b76c44146cd91fe20521b72`; its actual executable member hashes to `f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703`. Both Linux host receipts identify this binary and Linux aarch64. Every regular member of window2.tar.gz equals its retained extracted counterpart.

Rechecked 21 records in each window: three negative controls, three successful warmups and fifteen successful measurements in five rotating profile rounds. Input hashes, GNU-time wall/user/system/RSS/exit values, stderr result and recorded command agree with each JSON record. Monotonic wrapper elapsed is at least the coarse GNU-time elapsed. Across windows, all 30 measured positives and six warmups exit 0 with OK; all six corrected controls exit nonzero with Content hash mismatch at seq 0 (IntegrityEventHash).

For each profile in both windows, corrupted files are readable gzip/tar with unchanged member set and manifest bytes. Their event stream equals the original with exactly the first allow changed to equal-length block; original content hash and remaining event bytes are retained. Gzip container hashes need not match across windows because repacking can vary metadata; decoded mutations are verified directly. The original size-changing failure remains separate and is not counted as an intended content-hash control or successful measurement.

## Independent comparison

Recomputed every comparison.json statistic directly from measured wall_ns_with_wrapper and max_rss_kib records, without importing supplied analysis. All medians, minima and maxima match exactly; COMPARISON.md rounds them correctly.

| Profile | Window 1 median ms | Window 2 median ms | W2 range ms |
|---|---:|---:|---:|
| small | 36.641771 | 37.784428 | 35.244422–101.276045 |
| typical-pr | 257.056116 | 374.084065 | 210.167529–586.445467 |
| large | 2503.012558 | 2755.314505 | 2455.624509–5042.973187 |

First measured starts are 2026-10-18T21:13:33.210664+00:00 and 2026-10-18T21:21:37.730624+00:00. Exact start-to-start gap: 484.51996 seconds = 8.075332666666666 minutes, correctly rounded to 8.08. This is not an end-to-start quiet interval or longer-term stability evidence. Recount details are in independent-recount.json, outside the frozen manifest.

## Replay and regeneration review

README.md's offline replay route is usable for the inspected, hash-verified package. prepare_replay.py verifies the release archive and non-release inputs before copying, requires an existing parent with at least 2 GiB free, refuses an existing destination, extracts only the pinned regular executable into a fixed destination with a 100 MiB member ceiling, applies executable permissions and verifies all five prepared inputs. The copied inputs-v2.json becomes inputs.json, as the unchanged run script expects. The script refuses an existing results directory, checks input hashes and guest disk floors, uses bounded subprocess timeouts and retains the negative/warmup/measured outputs. README explicitly requires Linux aarch64/GNU time and disallows Python -O because the original guards use assertions.

Read the retained preparation-check.json and independently rehashed all five files at its still-present prepared destination. inputs.json equals the original map, the executable has execute permissions and no results directory exists. Retained receipts show successful preparation and failure on an existing destination. These are macOS preparation/hash checks only, not a Linux execution of the assembled replay kit. I did not rerun the helper or execute the binary. The helper assumes this inspected, manifest-verified package; this review does not claim it safely accepts arbitrary hostile replacement manifests or archives.

Regeneration instructions correctly use the pinned Git base plus retained overlay, the example build command, all three workload selectors and a fresh output directory. They identify the recorded Rust toolchain and state that the scoped source archive is not a standalone workspace. Comparing regenerated fixture hashes before substitution and treating mismatch as a new input series avoids silently changing exact replay. No independent rebuild is claimed.

## Verdict and limits

READY for retained-evidence correctness, bounded comparison and usable replay instructions. No actionable correction required. Comparison text appropriately distinguishes same-day repetition on the same shared VM from independent-host or longer-term evidence, avoids pooling into a population confidence interval, and sets no CI budget. Different medians with unchanged binary/inputs and uncontrolled host conditions do not establish a code regression or improvement. Both event count and payload size vary; elapsed includes launch/wrapper overhead, RSS is CLI high-water, and cache residency/continuous isolation were not measured.

This review does not authenticate clocks, machine state, absence of unrecorded runs, reviewer identity, sender identity or the retained release-attestation signatures. No fresh attestation check, Linux replay, benchmark, build, publication, issue closure or merge readiness is asserted. Any outer handoff archive and sibling SHA file mentioned in README are packaging obligations outside this directory-level review; their final bytes must be checked separately after packaging. Only independent-review.md and independent-recount.json were written, and all frozen inputs were rehashed unchanged at completion.
