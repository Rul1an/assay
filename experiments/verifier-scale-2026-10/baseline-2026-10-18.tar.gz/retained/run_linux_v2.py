#!/usr/bin/env python3
"""Bounded one-off execution receipt, no benchmark framework or thresholds."""
import hashlib,io,json,os,pathlib,platform,shutil,subprocess,tarfile,time,datetime
root=pathlib.Path(__file__).resolve().parent
os.chdir(root)
out=root/'results';out.mkdir(exist_ok=False)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def record(name,obj):(out/name).write_text(json.dumps(obj,indent=2)+'\n')
expected=json.loads((root/'inputs.json').read_text())
for name,digest in expected.items():assert sha(root/name)==digest,name
binary=root/'release/assay-v6.14.1-aarch64-unknown-linux-gnu/assay'
assert shutil.disk_usage(root).free>2*1024**3
record('host.json',{'utc':stamp(),'platform':platform.platform(),'cpu_count':os.cpu_count(),'meminfo':pathlib.Path('/proc/meminfo').read_text(),'cpuinfo':pathlib.Path('/proc/cpuinfo').read_text(),'disk_free':shutil.disk_usage(root).free,'binary_sha256':sha(binary),'version':subprocess.check_output([str(binary),'--version'],text=True),'time_version':subprocess.check_output(['/usr/bin/time','--version'],text=True)})
profiles=['small','typical-pr','large'];expected_counts=[1000,10000,100000];meta=[]
for profile,count in zip(profiles,expected_counts):
    path=root/(profile+'.tar.gz')
    assert path.stat().st_size<100*1024**2
    with tarfile.open(path,'r:gz') as t:
        members=t.getmembers();assert sum(m.size for m in members)<200*1024**2
        contents=[(m,t.extractfile(m).read()) for m in members]
    ev=next(data for m,data in contents if m.name=='events.ndjson')
    lines=ev.splitlines();assert len(lines)==count
    manifest=json.loads(next(data for m,data in contents if m.name=='manifest.json'))
    meta.append({'profile':profile,'events':count,'archive_bytes':path.stat().st_size,'events_bytes':len(ev),'archive_sha256':sha(path),'manifest':manifest})
    first=lines[0];assert b'"decision":"allow"' in first
    mutated=first.replace(b'"decision":"allow"',b'"decision":"block"',1)+ev[len(first):]
    bad=root/(profile+'-corrupt.tar.gz')
    with tarfile.open(bad,'w:gz') as t:
        for m,data in contents:
            data=mutated if m.name=='events.ndjson' else data
            m.size=len(data);t.addfile(m,io.BytesIO(data))
    meta[-1]['corrupt_sha256']=sha(bad)
record('profiles.json',meta)
def run(profile,kind,index):
    assert shutil.disk_usage(root).free>2*1024**3
    path=root/(profile+('-corrupt' if kind=='negative' else '')+'.tar.gz')
    prefix=out/f'{kind}-{index}-{profile}'
    argv=['/usr/bin/time','-f','%e %U %S %M %x','-o',str(prefix)+'.time',str(binary),'--color','never','evidence','verify',str(path)]
    started=stamp();before=time.perf_counter_ns()
    with open(str(prefix)+'.stdout','wb') as so,open(str(prefix)+'.stderr','wb') as se:
        try:r=subprocess.run(argv,stdout=so,stderr=se,timeout=120)
        except subprocess.TimeoutExpired:
            record(prefix.name+'.json',{'argv':argv,'utc':started,'timeout':True});raise
    elapsed=time.perf_counter_ns()-before
    err=pathlib.Path(str(prefix)+'.stderr').read_text()
    timing=pathlib.Path(str(prefix)+'.time').read_text().splitlines()[-1].split()
    row={'argv':argv,'utc':started,'profile':profile,'kind':kind,'index':index,'returncode':r.returncode,'wall_ns_with_wrapper':elapsed,'gnu_wall_s':float(timing[0]),'user_s':float(timing[1]),'system_s':float(timing[2]),'max_rss_kib':int(timing[3]),'input_sha256':sha(path)}
    record(prefix.name+'.json',row)
    if kind=='negative':assert r.returncode!=0 and 'content' in err.lower() and 'hash' in err.lower(),err
    else:assert r.returncode==0 and 'OK' in err,err
for p in profiles:run(p,'negative',0)
for p in profiles:run(p,'warmup',0)
for i in range(5):
    for p in profiles[i%3:]+profiles[:i%3]:run(p,'measured',i+1)
record('complete.json',{'utc':stamp(),'measurements':15,'warmups':3,'negative_controls':3,'disk_free':shutil.disk_usage(root).free})
