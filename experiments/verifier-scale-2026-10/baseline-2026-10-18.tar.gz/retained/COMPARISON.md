# Verifier repeatability — two retained time windows

Same released Assay 6.14.1 binary, SHA-256 `f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703`, source `098ebbeb2efe19c3b8fdc6bc41250c80169cc06c`. Same fixture bytes and unchanged run_linux_v2.py. Generator base `63f3ee6f5d8b3eb1d48e91912598d64aaff3eeb2` plus retained adapter; original worktree recorded in baseline/provenance.json.

First measured process starts (UTC): 2026-10-18T21:13:33.210664+00:00 and 2026-10-18T21:21:37.730624+00:00; gap 8.08 minutes. Each window: 5 measured fresh processes per profile after one warmup, rotating order. Same shared Linux ARM64 VM, no cache flush.

| Profile | Window 1 median ms (range) | Window 2 median ms (range) | Median peak RSS MiB W1 / W2 |
|---|---:|---:|---:|
| small | 36.64 (32.07–36.91) | 37.78 (35.24–101.28) | 12.06 / 12.06 |
| typical-pr | 257.06 (192.36–314.01) | 374.08 (210.17–586.45) | 15.88 / 15.88 |
| large | 2503.01 (2147.16–3956.58) | 2755.31 (2455.62–5042.97) | 84.75 / 84.75 |

All 30 measured positive verifications and six warmups across the two windows exited 0. All six corrected corrupted controls were rejected with Content hash mismatch at seq 0. The failed initial size-changing control remains retained separately. These are descriptive observations: a later median difference is neither a regression nor an improvement because the binary and inputs are unchanged and host conditions are not isolated. Do not pool these samples into an independent-population confidence interval or set a CI threshold from them.

Time includes process startup and GNU time wrapper; memory is the CLI high-water RSS. Both event counts and payload sizes increase between profiles, so this is not a pure event-count slope. The second window is same-day repeatability, not long-term stability or independent-host replication. A hash-checked replay kit and source instructions are in README.md. No production changes, merge, release, or issue closure are claimed.
