# Bounded verifier profile experiment

Three existing profiles: small (1000 events, 128 payload bytes), typical-pr (10000, 256), large (100000, 512). Both dimensions change; not a pure event-count scaling experiment. Generator is existing benchmark source with a retained entry-point adapter, on the recorded main SHA. Generation is excluded from all verifier measurements.

Verify retained files using released Assay 6.14.1 on Ubuntu aarch64. Record archive and executable hashes and release attestation. Five measured fresh-process repetitions per profile, rotating order each round, after one unmeasured warmup per profile. No cache flushing: warm filesystem, fresh processes; not cold-start proof. GNU time peak RSS includes the entire CLI process; Python monotonic elapsed includes process launch and time-wrapper overhead. No automatic threshold or population confidence interval. Retain every failure; never substitute retries.

Negative control: alter the first event decision allow to deny while retaining its original content hash and manifest, then repack as valid tar.gz. Verify once per profile, require nonzero exit and content-hash rejection. Do not count expected failures as successful verification. No claim about hostile-input worst-case memory or detection quality.

Preflight at least 5 GiB free on macOS, at least 2 GiB on guest. Stop on failed positive control, unexpected negative result, timeout, or resource floor. Retain artifacts and independently recount before reporting.

## Recorded pre-measurement correction
Attempt 1 stopped at the first negative control: allow -> deny shortened events.ndjson by one byte and correctly triggered IntegrityFileSizeMismatch. No measured positives were run. Attempt 2 uses equal-length allow -> block; all other method settings remain unchanged. Attempt 1 is retained, not overwritten.
