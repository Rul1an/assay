# Independent review — bounded #2174 measurement

Verdict: READY for the bounded conclusions in RESULT.md. No actionable findings.

Reviewer: Codex non-building subagent `/root/3103_final_review`. I did not author or edit this measurement's plan, helper, normative specification, or production/test code. Codex/root is the measurement author; Claude and Argon supplied advice. My review is independent source and retained-evidence inspection, not an independent runtime reproduction. A publisher relaying this review is not the reviewing agent; externally authenticated reviewer identity or independence is not claimed.

Subject source: `05fb46761b6f648ff458d500b155aefb81fb1ee0`.
Frozen manifest: `REVIEW-MANIFEST.json`, SHA-256 `e94744de6dc06a3e041e1285b87f2f3d41772c26e287c89427171b3d0d9f41f1` (62 entries).
Source archive SHA-256: `7ed59c0ee11c396892a8403c9a460afc1381a7325db1d6f85260ae87f37aa16d`.
Packet: `/Users/roelschuurkes/assay-review-records/2174-bounded-probe-2026-10-20`.
Measured workspace: `/home/ubuntu/2174-probe/source` on Linux aarch64 guest `assay-replay-clean-20261019`; rustc 1.96.0. I read immutable Git objects from `/Users/roelschuurkes/assay` without touching its working tree.

## Checks and conclusion

- Independently recomputed all 62 frozen-file hashes. Independently reconstructed the pinned Git archive in memory and compared all 5,543 regular-file hashes with the transferred archive inventory. The input archive and probe hashes agree with the retained guest input hashes.
- Read PLAN.md, RESULT.md, both runner scripts, metadata, mutation patches, baseline/mutant/restored logs, resource samples, validation record, and historical comparison. The helper always starts each isolated mutation from original verifier bytes; commands use exact named tests, no shared target and one build job. Source restoration runs in finally. The runner's coarse panic/exit checks are not themselves sufficient semantic classification; the retained raw failures supply that classification here.
- Recounted 17 actual one-test invocations: 10 successes and 7 expected assertion failures. The raw logs show successful compilation and the intended named tests running, not compile failures, zero-test filters, skips, timeouts or resource stops. E5 introduces warnings, not a failed compilation.
- S4 removes only duplicate refusal while retaining seen-file insertion: Quick reports one duplicate bypass, and the existing duplicate-specific assertion fails Passed versus Blocked. E2 changes only the decoded ceiling to u64::MAX: Quick reports one decode-bomb bypass and the corresponding existing assertion fails Passed versus Blocked.
- E5 replaces the trailer drain read with typed Ok(0), leaving the unread-source check intact. Quick fails earlier at the CRLF invariant (lib.rs:155); this is not evidence that its later CRC-message assertion executed. The separate CRC-specific test reaches integrity.rs:309 and fails because rejection says Data after the end of the gzip stream instead of Gzip trailer. RESULT.md preserves this distinction correctly.
- The wrong-reason control still refuses the duplicate but fails the Quick code pin at lib.rs:186. The inert duplicate-message control passes. This supports reason sensitivity for the named comparison without implying arbitrary diagnostic wording is pinned.
- Each mutant/control log shows compilation of assay-evidence and an identified changed test-binary digest; paired specific tests use the same digest. Recorded restored source hash equals original; helper snapshot verifies all source files restored. Restored binary digest equals baseline `d35678841d568074bcf99165a67fd6b5397cb57dbae462999e7d6d85a8b4f50e`, and all four restored named tests pass. Binary equality is verified between retained metadata records, not by retrieving the guest executable independently.
- Independently recomputed sampled resource minima: guest free disk 5,053,456,384 bytes; guest available memory 1,974,386,688 bytes; host free disk 10,650,365,952 bytes. These are sampled minima, not continuous-resource guarantees. Dispatch exit is 0 with no stop.
- Verified historical old/current Git blob comparisons: selected simulation fixtures/tests are identical to the earlier repair; verifier source changed. The historical review is explicitly relayed evidence with no retrieved historical raw logs. Fresh Linux observations are kept separate; the result does not pretend to discover an unfixed historical defect.

The packet supports the narrow conclusion that the existing tests detect the three specified mutations and the selected reason change on this source pin. No missing assertion was demonstrated, so declining production/test edits is appropriate. Keep #2174 open for unmeasured scope.

## Non-claims

No independent runtime rerun, full verifier coverage, complete gate matrix, mutation score, real-world detection rate, complete workspace verification, hosted CI, merge, or release claim. The helper is a bounded local measurement tool, not a generalized hardened runner; unexercised stop-path behavior is not established by this successful run. No frozen packet files or repository files were edited; only this review record was written.
