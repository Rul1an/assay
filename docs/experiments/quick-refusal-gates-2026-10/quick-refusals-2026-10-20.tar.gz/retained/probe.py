import os, sys, json, time, pathlib, subprocess, hashlib, shutil, signal, difflib
ROOT=pathlib.Path('/home/ubuntu/2174-probe/source'); OUT=ROOT.parent/'results';OUT.mkdir(exist_ok=False)
V=ROOT/'crates/assay-evidence/src/bundle/writer_next/verify.rs'; original=V.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
env=os.environ.copy();env.pop('CARGO_TARGET_DIR',None)
env.update(CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
env['PATH']='/home/ubuntu/.cargo/bin:'+env['PATH']
Q='tests::test_quick_suite'; prefix='attacks::integrity::tests::'
D=prefix+'tar_duplicate_is_refused_as_duplicate_file'; Z=prefix+'zip_bomb_is_refused_as_limit_decode_bytes'; G=prefix+'bitflip_crc_is_refused_as_integrity_gzip'
meta={'head':'05fb46761b6f648ff458d500b155aefb81fb1ee0','cwd':str(ROOT),'uname':subprocess.check_output(['uname','-a'],text=True),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'env':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']},'original_verify_sha256':sha(original),'cases':[]}
(OUT/'metadata.json').write_text(json.dumps(meta,indent=2))
def snapshot():
    files={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file() and 'target' not in p.relative_to(ROOT).parts}
    return files
before=snapshot();(OUT/'source-files.json').write_text(json.dumps(before,sort_keys=True))
def run(label,test,expected):
    cmd=['cargo','test','--locked','-p','assay-sim','--lib',test,'--','--exact','--nocapture']
    log=OUT/(label+'.log'); start=time.time(); reason=None
    with log.open('xb') as f:
        p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        (OUT/'active.json').write_text(json.dumps({'pid':p.pid,'pgid':p.pid,'label':label}))
        with (OUT/(label+'.resources.jsonl')).open('x') as rr:
            while p.poll() is None:
                m={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
                r={'at':time.time(),'disk_free':shutil.disk_usage(ROOT).free,'mem_available':m['MemAvailable'],'log_bytes':log.stat().st_size};rr.write(json.dumps(r)+'\n');rr.flush()
                if r['disk_free']<1024**3:reason='guest_disk_floor'
                if r['mem_available']<200*1024**2:reason='guest_memory_floor'
                if r['log_bytes']>20*1024**2:reason='output_cap'
                if time.time()-start>1500:reason='timeout'
                if reason:
                    os.killpg(p.pid,signal.SIGTERM)
                    try:p.wait(timeout=10)
                    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
                    break
                time.sleep(2)
    text=log.read_text(errors='replace')
    binaries=[x for x in (ROOT/'target/debug/deps').glob('assay_sim-*') if x.is_file() and os.access(x,os.X_OK) and not x.suffix]
    rec={'label':label,'command':cmd,'exit':p.returncode,'seconds':time.time()-start,'resource_stop':reason,'source_sha256':sha(V.read_bytes()),'test':test,'expected_exit':expected,'binary_sha256':{x.name:sha(x.read_bytes()) for x in binaries},'log_sha256':sha(log.read_bytes())}
    meta['cases'].append(rec);(OUT/'metadata.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(rec),flush=True)
    assert not reason,reason
    assert 'running 1 test' in text and 'test result:' in text,'test not executed'
    assert p.returncode==expected,(label,p.returncode,expected)
    if expected:assert 'panicked at' in text,'not an assertion failure'
def change(label,a,b):
    s=original.decode();assert s.count(a)==1,(label,s.count(a));changed=s.replace(a,b);V.write_text(changed)
    (OUT/(label+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),changed.splitlines(True),fromfile=str(V.relative_to(ROOT)),tofile=str(V.relative_to(ROOT)))))
try:
    for i in [1,2]:run('baseline-quick-'+str(i),Q,0)
    for name,t in [('duplicate',D),('decode',Z),('crc',G)]:run('baseline-'+name,t,0)
    cases=[('S4','if !seen_files.insert(path_str.to_string()) {','if { seen_files.insert(path_str.to_string()); false } {',D),('E2','LimitReader::new(decoder, limits.max_decode_bytes, LimitKind::DecodedBytes)','LimitReader::new(decoder, u64::MAX, LimitKind::DecodedBytes)',Z),('E5','match tail.read(&mut drain) {','match Ok::<usize, std::io::Error>(0) {',G)]
    for name,a,b,t in cases:
        change(name,a,b);run(name+'-quick',Q,101);run(name+'-specific',t,101);V.write_bytes(original)
    change('positive-wrong-reason','ErrorCode::ContractDuplicateFile,','ErrorCode::ContractUnexpectedFile,');run('positive-wrong-reason',Q,101);V.write_bytes(original)
    change('inert-message','"Duplicate file \'{}\'"','"Duplicate archive member \'{}\'"');run('inert-message',Q,0);V.write_bytes(original)
    for name,t in [('quick',Q),('duplicate',D),('decode',Z),('crc',G)]:run('restored-'+name,t,0)
    assert snapshot()==before,'source changed beyond restored verifier'
    meta['completed']=True
except BaseException as e:
    meta['completed']=False;meta['error']=repr(e);raise
finally:
    V.write_bytes(original);meta['restored_verify_sha256']=sha(V.read_bytes());meta['source_restored']=snapshot()==before
    (OUT/'metadata.json').write_text(json.dumps(meta,indent=2));(OUT/'active.json').unlink(missing_ok=True)
