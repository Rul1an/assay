# Independent retained-result review — events-byte resource pilot

Verdict: READY. No actionable findings for the bounded report.

Actual reviewer: codex/refusal_publication_review. Builder/executor: codex/root. Argon was design advisor. I authored neither the plan, fixtures, runner nor report. My work was read-only review plus the separate independent recount artifacts; I did not run the product executable, build, use a VM or contact a network service.

Frozen RESULT-MANIFEST.json SHA256: bb8e25327e88a05411d7d87a5c83ead21528b7184468f412aa5d946a42cabf96.
Measured executable SHA256: f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703.
Recorded release source: 098ebbeb2efe19c3b8fdc6bc41250c80169cc06c; comparison main: 20b9aa018d4a0d628698680871f1824a0b44aea3.

## Independent checks

- Recalculated all87 file hashes in RESULT-MANIFEST and every PRE-RUN-MANIFEST entry. Both inventories match. The immutable manifest remains unchanged after review. Five retained source snapshots match the hashes in source-parity.json; I did not freshly fetch source or authenticate source-to-binary provenance.
- Independently read the1000 seed events and recomputed their content-hash inputs. For these specific ASCII/string/integer JSON inputs, compact key-sorted Python JSON matches the source-declared JCS preimage. This recount is not a general JCS implementation. Original event byte sequences and content hashes remain unchanged in every padded event.
- Stream-read all four complete fixture bodies, bounded to approximately1MiB per line/chunk. Confirmed100/500/1000/1000 events, exact50/250/500MiB and500MiB+1byte member sizes, complete final lines, only trailing ASCII-space padding, manifest byte counts and SHA256 values, event counts, newline-delimited run roots and bundle IDs. Independently drained gzip streams through their trailers. The oversized witness has a real complete body, not merely an oversized header.
- Recounted13 raw process records and GNU-time outputs, not just summary.json. Verified seed plus three prescribed rotations,10 exit0 outcomes and3 exit2 LimitFileSize outcomes, empty stdout, exact524288000-byte diagnostic, matching input digests, ordered timestamps, no timeout, and no observed Runner.Worker at the recorded samples. GNU-time exit values match wrapper exits and metrics match raw time files. Original absent-binary preflight failure remains retained separately.
- Recomputed the full summary exactly.50MiB RSS range12.125–12.250MiB,250MiB12.625MiB,500MiB13.125MiB; elapsed medians0.08/0.42/0.85seconds. Oversized refusal RSS12.250MiB and displayed elapsed0.00seconds. The report correctly treats0.00 as display resolution, not zero elapsed time, and keeps wall-clock/polling duration separate.
- Runner hash and executable hash match host.json; the actual runner/host guard is1536MiB, consistent with the explicit final pre-execution amendment rather than initial768MiB. Admission samples exceed stated disk/memory floors. No guard failure is hidden as a successful refusal in the retained outcomes.
- Source verify.rs applies the strict header_size > max_size check before entering events parsing; limits.rs sets500MiB. The exact-boundary successes and above-boundary diagnostics support declared-size preflight attribution. This is source ordering plus outcomes, not an instrumented trace; it does not rule out decoder/read-ahead buffering or prove in-stream-limit enforcement.

## Claim ceiling

The report adequately limits conclusions to this file route, released binary, existing shared ARM64 guest and highly compressible whitespace-rich input. Low measured RSS across these runs supports the bounded observation that the whole500MiB member was not simultaneously resident; it does not establish a universal upper bound, causal event-byte scaling, realistic-payload throughput, complete activity isolation or independent-host reproducibility. Changing event count and compressed size is disclosed. No CI threshold, quality-rate or product correction is justified by these results. No production/schema changes or #2494 completion are claimed.

The reviewer executed only the independently written local Python standard-library recount against retained bytes. This is independent result inspection, not independent product execution, implementation or fresh release attestation. Agent identity and independence are declared, not externally authenticated. No publication or merge action taken.

## Recount artifacts

independent-recount.py and independent-recount.json contain the executable recount and its result. They are new review artifacts outside the frozen manifest; original evidence was not edited.
