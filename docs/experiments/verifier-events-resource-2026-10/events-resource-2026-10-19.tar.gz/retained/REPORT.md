# Events-byte resource pilot — 2026-10-19

Measured release: Assay v6.14.1 Linux aarch64 GNU; source098ebbeb2efe19c3b8fdc6bc41250c80169cc06c; binary SHA256 f97312764e2b63494a4c13e6ba2341ce1405019c97ac63a78edd08d5ab92b703. Current-main comparison20b9aa018d4a0d628698680871f1824a0b44aea3: five selected source files identical (source-parity.json); not source-to-binary or full-tree equivalence proof. No production edits or Rust rebuild.

Codex/root generated and ran fixtures on existing shared Ubuntu Linux ARM64 Multipass guest assay-bpf-runner. Argon gemini-4-argon-high advised design. Independent review requested separately; neither model agreement nor runner completion alone establishes correctness.

## Method

See PLAN.md (original proposal), PLAN-final.md (pre-execution amendment), generate.py, cases.json, PRE-RUN-MANIFEST.json and raw results/. Seed1000 original events, fixed512KiB NDJSON lines with trailing ASCII whitespace. Prefix100/500/1000 events yields50/250/500MiB; fourth input has one extra byte and complete body, with recomputed valid manifest metadata. Original content hashes preserved, prefix run roots recomputed. No new event schema. All inputs below compressed-source,decoded,line,count and path limits except the targeted events ceiling in the fourth case.

One seed positive control, then three predeclared rotated rounds of four cases, no retries:13invocations,10successful verifications including seed,3expected refusals. GNU time reports child-process peak RSS and elapsed seconds with0.01s display resolution. run.py also records wall-clock duration including polling overhead; it is not interchangeable with GNU time. The external virtual-address guard was1536MiB (not initial768MiB), output files64KiB and timeout120seconds. No timeout,signal,guard failure or active runner worker was observed at recorded before/after samples. Samples do not exclude every transient background task. A prior preflight failed because the historical binary path was absent; retained stderr records this, and no measured attempt was replaced. Binary restored from hash-checked retained releasearchive; historical attestation in original releasepin is not fresh verification.

## Results

| Events member | n | Peak RSS MiB range | Median GNU elapsed s | Outcome |
|---|---:|---:|---:|---|
|50MiB|3|12.125–12.250|0.08|exit0|
|250MiB|3|12.625–12.625|0.42|exit0|
|500MiB exactly|3|13.125–13.125|0.85|exit0|
|500MiB+1byte|3|12.250–12.250|0.00 (instrument display)|exit2, LimitFileSize|

Raw JSON, GNU-time files, stdout and stderr are authoritative; summary.json is derived. Empty stdout and exact refusal ceiling524288000 checked. At the inclusive boundary all500MiB were successfully verified; just above it the declared-size preflight refused before consuming events content, consistent with source ordering. No instrumented call trace was collected.

## Decision and limits

No defect demonstrated on this route/workload; no parser or default-limit change justified. RSS grew about1MiB from50 to500MiB events, while compressed input and event count also grew. Results are inconsistent with materializing the whole500MiB events member in resident memory in these runs; they do not prove a universal RSS upper bound or pure event-byte causal slope.

This highly compressible whitespace-rich synthetic workload has small semantic event content and fixed512KiB lines. It does not cover high-entropy compressed sources, maximum semantic payload/line/count/depth limits, other reader routes, signed attestation, malformed in-stream expansion, production throughput, cold caches, independent-host repeatability or FPR/FNR. An above-limit declared header refusal is not streaming enforcement proof. Do not derive CI thresholds or confidence intervals from three same-session runs. No independent implementation, authentication or provider-outcome claim. #2494 remains open; stop this bounded slice after review rather than adding dimensions without a concrete question.

## Replay

Use compatible Linux aarch64 GNU with Python3 and GNU time. Place the pinned executable as assay beside run.py, release-pin.json, cases.json, seed.tar.gz and inputs/. Validate PRE-RUN-MANIFEST.json first. Use a fresh directory (results/ must not exist); run python3 run.py retaining wrapper stdout/stderr/exit. The runner requires4GiB free guest disk and2GiB MemAvailable, and refuses an observed Runner.Worker. These are this experiment's admission limits, not product minimums. Fixtures are retained compressed; generate.py can reproduce them in a separate fresh directory using seed.tar.gz. Run-level measurements exclude fixture generation and hashing. Do not overwrite historical results with a replay.
