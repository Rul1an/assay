import hashlib,json,os,platform,resource,shutil,signal,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'results';out.mkdir()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def resources():
    mem={k:int(v.split()[0])*1024 for k,v in (l.split(':',1) for l in Path('/proc/meminfo').read_text().splitlines())}
    return {'disk_free':shutil.disk_usage(root).free,'memory_available':mem['MemAvailable'],'runner_worker_present':subprocess.run(['pgrep','-x','Runner.Worker'],capture_output=True).returncode==0}
def guard():
    x=resources()
    if x['disk_free']<4*1024**3 or x['memory_available']<2*1024**3 or x['runner_worker_present']:raise RuntimeError('guest resource or shared-runner admission: '+str(x))
    return x
binary=root/'assay';pin=json.loads((root/'release-pin.json').read_text());assert sha(binary)==pin['binary_sha256']
cases=json.loads((root/'cases.json').read_text())
for c in cases:assert sha(root/'inputs'/(c['name']+'.tar.gz'))==c['sha256']
host={'platform':platform.platform(),'uname':list(platform.uname()),'started_epoch':time.time(),'binary_sha256':sha(binary),'release_pin':pin,'runner_sha256':sha(Path(__file__)),'cases_sha256':sha(root/'cases.json'),'time_version':subprocess.check_output(['/usr/bin/time','--version'],stderr=subprocess.STDOUT,text=True),'time_sha256':sha(Path('/usr/bin/time')),'meminfo':Path('/proc/meminfo').read_text(),'admission':guard(),'limits':{'virtual_address_space_bytes':1536*1024**2,'output_file_bytes':65536,'timeout_seconds':120,'guest_disk_floor_bytes':4*1024**3,'guest_mem_available_floor_bytes':2*1024**3}}
(out/'host.json').write_text(json.dumps(host,indent=2)+'\n')
def limits():
    resource.setrlimit(resource.RLIMIT_AS,(1536*1024**2,1536*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(65536,65536))
def run(c,round_number):
    before=guard();path=root/'seed.tar.gz' if c['name']=='seed' else root/'inputs'/(c['name']+'.tar.gz')
    prefix=out/f"r{round_number}-{c['name']}"
    argv=[str(binary),'--color','never','evidence','verify',str(path)]
    cmd=['/usr/bin/time','-f','{"elapsed_s":%e,"user_s":%U,"system_s":%S,"peak_rss_kib":%M,"exit":%x}','-o',str(prefix)+'.time',*argv]
    start=time.time();timeout=False
    with Path(str(prefix)+'.stdout').open('xb') as so,Path(str(prefix)+'.stderr').open('xb') as se:
        proc=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,preexec_fn=limits,start_new_session=True)
        try:code=proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timeout=True;os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            code=proc.returncode
    stderr=Path(str(prefix)+'.stderr').read_text(errors='replace');stdout=Path(str(prefix)+'.stdout').read_bytes()
    raw_time=Path(str(prefix)+'.time').read_text();metrics=None
    for line in raw_time.splitlines():
        try:metrics=json.loads(line)
        except json.JSONDecodeError:pass
    after=resources()
    ok=not timeout and code==c['expected_exit'] and not stdout and metrics is not None
    if c['expected_exit']==0:ok=ok and 'OK' in stderr
    else:ok=ok and '(LimitFileSize)' in stderr and '524288000' in stderr
    if after['runner_worker_present']:ok=False
    row={'case':c['name'],'round':round_number,'argv':argv,'input_sha256':sha(path),'expected_exit':c['expected_exit'],'exit':code,'timeout':timeout,'started_epoch':start,'finished_epoch':time.time(),'wall_clock_s':time.time()-start,'metrics':metrics,'before':before,'after':after,'oracle_match':bool(ok)}
    Path(str(prefix)+'.json').write_text(json.dumps(row,indent=2)+'\n')
    return row
rows=[]
try:
    seed={'name':'seed','expected_exit':0};rows.append(run(seed,0))
    if not rows[-1]['oracle_match']:raise RuntimeError('seed control failed')
    for rnd in range(3):
        order=cases[rnd:]+cases[:rnd]
        for c in order:
            row=run(c,rnd+1);rows.append(row)
            if not row['oracle_match']:raise RuntimeError('case mismatch; stop without replacement: '+c['name'])
    (out/'complete.json').write_text(json.dumps({'invocations':len(rows),'matched':sum(x['oracle_match'] for x in rows),'rows':[f"r{x['round']}-{x['case']}.json" for x in rows],'finished_epoch':time.time()},indent=2)+'\n')
except BaseException as e:
    (out/'failure.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e),'completed_rows':len(rows)},indent=2)+'\n')
    raise
