import hashlib,json,tarfile,gzip,statistics,time
from pathlib import Path
R=Path(__file__).resolve().parent
PIN='bb8e25327e88a05411d7d87a5c83ead21528b7184468f412aa5d946a42cabf96'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert sha(R/'RESULT-MANIFEST.json')==PIN
manifest=json.loads((R/'RESULT-MANIFEST.json').read_text())
for n,h in manifest.items():assert sha(R/n)==h,n
for n,h in json.loads((R/'PRE-RUN-MANIFEST.json').read_text()).items():assert sha(R/n)==h,n
with tarfile.open(R/'seed.tar.gz') as t:
 seed=t.extractfile('events.ndjson').read(2*1024*1024).splitlines()
assert len(seed)==1000
# This retained fixture's hash inputs are ASCII strings/objects/integer values;
# compact key-sorted JSON agrees with JCS here, not a generic JCS implementation.
def simple(v):
 if isinstance(v,dict):return all(isinstance(k,str) and k.isascii() and simple(x) for k,x in v.items())
 if isinstance(v,list):return all(map(simple,v))
 return v is None or isinstance(v,bool) or (isinstance(v,int) and abs(v)<=9007199254740991) or (isinstance(v,str) and v.isascii())
for b in seed:
 e=json.loads(b); pre={k:e[k] for k in ['specversion','type','datacontenttype','data']}
 if e.get('subject') is not None:pre['subject']=e['subject']
 assert simple(pre)
 assert 'sha256:'+hashlib.sha256(json.dumps(pre,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==e['assaycontenthash']
cases=json.loads((R/'cases.json').read_text()); fixturechecks=[]
for c in cases:
 p=R/'inputs'/(c['name']+'.tar.gz');assert sha(p)==c['sha256'] and p.stat().st_size==c['archive_bytes']
 with tarfile.open(p,mode='r|gz') as t:
  a=t.next();assert a.name=='manifest.json' and a.size<10485760;m=json.load(t.extractfile(a))
  a=t.next();assert a.name=='events.ndjson' and a.size==c['events_bytes'];f=t.extractfile(a);h=hashlib.sha256();roots=hashlib.sha256();count=total=0
  while True:
   b=f.readline(1048577)
   if not b:break
   assert len(b)<=1048576 and count<c['events'];assert b.endswith(b'\n');assert b.rstrip(b' \n')==seed[count]
   assert len(b)==(c['last_line_bytes'] if count==c['events']-1 else c['line_bytes'])
   e=json.loads(b);roots.update((e['assaycontenthash']+'\n').encode());h.update(b);count+=1;total+=len(b)
  assert t.next() is None
  assert count==c['events']==m['event_count'];assert total==c['events_bytes']==m['files']['events.ndjson']['bytes'];assert h.hexdigest()==c['events_sha256'];assert 'sha256:'+h.hexdigest()==m['files']['events.ndjson']['sha256'];assert 'sha256:'+roots.hexdigest()==m['run_root']==m['bundle_id']
 # Drain gzip independently to verify full body/trailer, bounded 1MiB chunks.
 with gzip.open(p,'rb') as f:
  decoded=0
  for b in iter(lambda:f.read(1048576),b''):decoded+=len(b);assert decoded<1024**3
 fixturechecks.append({'case':c['name'],'events':count,'event_bytes':total,'decoded_bytes':decoded,'sha256':c['sha256']})
complete=json.loads((R/'results/complete.json').read_text());assert complete['invocations']==complete['matched']==13
expected=['r0-seed.json']+[f'r{rnd+1}-{c["name"]}.json' for rnd in range(3) for c in cases[rnd:]+cases[:rnd]];assert complete['rows']==expected
summary={};prev=0
for n in expected:
 p=R/'results'/n;r=json.loads(p.read_text());pre=p.with_suffix('');raw=pre.with_suffix('.time').read_text();tm=json.loads(raw.splitlines()[-1]);assert tm==r['metrics'];assert tm['exit']==r['exit']==r['expected_exit'];assert not r['timeout'] and r['oracle_match'];assert not pre.with_suffix('.stdout').read_bytes();err=pre.with_suffix('.stderr').read_text();assert r['started_epoch']>=prev;prev=r['finished_epoch'];assert not r['before']['runner_worker_present'] and not r['after']['runner_worker_present'];assert r['before']['disk_free']>=4*1024**3 and r['before']['memory_available']>=2*1024**3
 assert r['input_sha256']==sha(R/'seed.tar.gz' if r['case']=='seed' else R/'inputs'/(r['case']+'.tar.gz'))
 if r['exit']==0:assert 'OK' in err
 else:assert r['exit']==2 and '(LimitFileSize)' in err and '524288000' in err
 summary.setdefault(r['case'],[]).append(r)
recount={}
for name,rs in summary.items():
 mem=[r['metrics']['peak_rss_kib']/1024 for r in rs];elapsed=[r['metrics']['elapsed_s'] for r in rs]
 recount[name]={'n':len(rs),'exits':[r['exit'] for r in rs],'rss_mib_min':min(mem),'rss_mib_median':statistics.median(mem),'rss_mib_max':max(mem),'gnu_elapsed_s_min':min(elapsed),'gnu_elapsed_s_median':statistics.median(elapsed),'gnu_elapsed_s_max':max(elapsed)}
assert recount==json.loads((R/'summary.json').read_text())
host=json.loads((R/'results/host.json').read_text());assert host['runner_sha256']==sha(R/'run.py');assert host['binary_sha256']==sha(R/'assay');assert host['limits']['virtual_address_space_bytes']==1536*1024**2
assert sha(R/'RESULT-MANIFEST.json')==PIN
(R/'independent-recount.json').write_text(json.dumps({'manifest_sha256':PIN,'manifest_files_checked':len(manifest),'review_script_sha256':sha(Path(__file__)),'fixtures':fixturechecks,'summary':recount,'product_binary_executed':False},indent=2)+'\n')
print('PASS',len(manifest),'hashes; seed1000 content hashes; four complete streaming fixtures; 13 raw results; summary exact')
