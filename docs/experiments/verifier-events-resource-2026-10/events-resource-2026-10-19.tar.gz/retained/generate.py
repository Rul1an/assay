import gzip,hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
LINE=524288
seed=root/'seed.tar.gz'
with tarfile.open(seed) as t:
    manifest=json.load(t.extractfile('manifest.json'))
    lines=t.extractfile('events.ndjson').read().splitlines()
assert len(lines)==1000
out=root/'inputs';out.mkdir()
def chunks(n,extra):
    for i,line in enumerate(lines[:n]):
        padding=LINE-len(line)-1+(extra if i==n-1 else 0)
        assert padding>=0
        yield line+b' '*padding+b'\n'
def header(name,size):
    h=tarfile.TarInfo(name);h.size=size;h.mode=0o644;h.mtime=0
    return h.tobuf(format=tarfile.USTAR_FORMAT)
cases=[]
for name,n,extra in [('50MiB',100,0),('250MiB',500,0),('500MiB',1000,0),('500MiB-plus1',1000,1)]:
    size=n*LINE+extra
    sha=hashlib.sha256()
    for chunk in chunks(n,extra):sha.update(chunk)
    hashes=[json.loads(line)['assaycontenthash'] for line in lines[:n]]
    runroot='sha256:'+hashlib.sha256(''.join(h+'\n' for h in hashes).encode()).hexdigest()
    m=json.loads(json.dumps(manifest));m['event_count']=n;m['run_root']=runroot;m['bundle_id']=runroot
    m['files']['events.ndjson']['bytes']=size;m['files']['events.ndjson']['sha256']='sha256:'+sha.hexdigest()
    data=json.dumps(m,sort_keys=True,separators=(',',':')).encode()
    p=out/(name+'.tar.gz')
    with p.open('xb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as z:
        z.write(header('manifest.json',len(data)));z.write(data);z.write(b'\0'*((-len(data))%512))
        z.write(header('events.ndjson',size))
        for chunk in chunks(n,extra):z.write(chunk)
        z.write(b'\0'*((-size)%512));z.write(b'\0'*1024)
    compressed=p.stat().st_size
    assert compressed<100*1024*1024 and LINE+extra<1024*1024 and size+8192<1024**3
    cases.append({'name':name,'events':n,'events_bytes':size,'line_bytes':LINE,'last_line_bytes':LINE+extra,'archive_bytes':compressed,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'events_sha256':sha.hexdigest(),'expected_exit':2 if extra else 0,'expected_code':'LimitFileSize' if extra else None})
(root/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(root/'generation.json').write_text(json.dumps({'seed_sha256':hashlib.sha256(seed.read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'line_bytes':LINE,'semantics':'original JSON events; ASCII spaces before newline; prefix root recomputed; complete oversized body retained'},indent=2)+'\n')
print(json.dumps(cases,indent=2))
