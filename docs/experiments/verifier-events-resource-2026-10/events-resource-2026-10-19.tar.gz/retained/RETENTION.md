# Publication subset

Original raw inputs, run results, scripts and reports retain their exact bytes. The full local experiment was reviewed against RESULT-MANIFEST.json; that historical inventory and PRE-RUN-MANIFEST.json include files not distributed here. They are NOT publication completeness manifests. PUBLICATION-MANIFEST.json inventories every payload file in this archive except itself.

The release executable is obtained separately and checked against release-pin.json. Raw Argon transcripts are omitted. Duplicate transport/package archives and Python bytecode are omitted. The full original evidence remains retained locally. The independent historical review checked87 files in the original package, including the executable and design transcript; that claim describes the original package, not this publication subset. independent-recount.py is the unchanged historical reviewer script, which requires the full original inventory and writes its result; do not run it over this subset. Its retained output and review remain readable here. Replay the product with the README instructions instead.

No fresh product run, fresh release attestation, independent implementation or issue completion is implied by packaging. The publication review is separate from the historical result review.

Excluded original paths:

- FINAL-MANIFEST.json
- __pycache__/run.cpython-314.pyc
- argon-design.json
- argon-design.stderr
- argon-outcome.json
- argon-outcome.stderr
- assay
- compact-evidence.tar.gz
- compact-evidence.tar.gz.sha256
- results.tar.gz
- transfer.tar
