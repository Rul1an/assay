import datetime,hashlib,json,os,platform,subprocess,time
from pathlib import Path
root=Path('/home/ubuntu/proxy-cost-v6.22.0-20261104');source=root/'source';binary=root/'binary/assay-mcp-server-v6.22.0-aarch64-unknown-linux-gnu/assay-mcp-server'
expected='d1726853202153c0bdd5f49b1b51593f8753d97d0591ac420f681033c6ee91eb'
def snapshot():
 return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'python':platform.python_version(),'cpu_count':os.cpu_count(),'loadavg':os.getloadavg(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_hashes':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file() and '__pycache__' not in p.parts},'processes':subprocess.check_output(['ps','-eo','pid,ppid,comm'],text=True)}
for i in range(1,4):
 before=snapshot();assert before['binary_sha256']==expected
 for line in before['processes'].splitlines()[1:]:
  assert line.split()[-1] not in ('cargo','rustc','clippy-driver','assay-mcp-server'),line
 attempt=root/f'attempt-{i}';attempt.mkdir();(attempt/'before.json').write_text(json.dumps(before,indent=2)+'\n')
 cmd=['python3','docs/experiments/mcp-proxy-cost-2026-10/proxy_cost_pilot.py','--mcp-binary',str(binary),'--expected-binary-sha256',expected,'--release-tag','v6.22.0','--release-source-sha','d13a9bd7342bc3fbbd990acad27a0bd4be9963fb','--release-archive-sha256','4d599877dc0fb894b54183ea524f2742425fcaa934b17aec4f49ac18eae35169','--out-dir',str(attempt/'result'),'--blocks','20','--calls-per-session','20','--timeout-seconds','30','--bootstrap-resamples','2000']
 with (attempt/'stdout.log').open('xb') as out,(attempt/'stderr.log').open('xb') as err:
  result=subprocess.run(cmd,cwd=source,stdout=out,stderr=err)
 after=snapshot();(attempt/'after.json').write_text(json.dumps(after,indent=2)+'\n');(attempt/'execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(source),'returncode':result.returncode},indent=2)+'\n')
 assert result.returncode==0,f'run{i}failed'
 assert before['source_hashes']==after['source_hashes'] and after['binary_sha256']==expected
 print(f'run{i}: completed; input hashes unchanged',flush=True)
 if i<3:time.sleep(30)
