"""Recipient-only recount; does not import or execute supplied analysis/harness."""
from pathlib import Path
import json, hashlib, tarfile, statistics, random, math, datetime
P=Path(__file__).resolve().parent
def read(p):return json.loads((P/p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def lines(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def instant(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
manifest=read('PACKAGE-MANIFEST.json')
assert len(manifest)==740
for name,digest in manifest.items(): assert sha(P/name)==digest,name
plan=read('PLAN.json');assert sha(P/'PLAN.json')==(P/'PLAN.sha256').read_text().split()[0]
assert sha(P/'execute.py')==plan['executor_sha256']
source=read('source-manifest-d4da91b0a0a5.json')
with tarfile.open(P/'source-d4da91b0a0a5.tar') as t:
 members={m.name.removeprefix('./'):m for m in t.getmembers() if m.isfile()}
 for name,digest in source['files'].items():
  assert hashlib.sha256(t.extractfile(members[name]).read()).hexdigest()==digest
  assert sha(P/'source'/name)==digest
keys=['startup_ms','in_session_call_median_ms','in_session_call_total_ms','closure_flush_ms','evidence_bytes_per_session']
results=[];previous_end=None
for n in range(1,4):
 tag=f'run-{n:02}';q=P/'raw'/tag;sup=read(tag+'-supervisor.json')
 assert sup['exit_code']==0 and instant(plan['frozen_at'])<instant(sup['started_at'])
 if previous_end:assert (instant(sup['started_at'])-previous_end).total_seconds()>=30
 previous_end=instant(sup['ended_at'])
 for suffix in ['before','after']:
  obs=read(tag+'-'+suffix+'.json');assert obs['files']==source['files'];assert obs['binary']=='787403002c677892593c5bafe89ebe183cb1516e959c5feac1ae72249882960c';assert not obs['conflicting_processes'];assert obs['disk_free']>=plan['floors']['guest_disk_bytes']
  assert read('host-'+tag+'-'+suffix+'.json')['disk_free']>=plan['floors']['host_disk_bytes']
 transfer=read(tag+'-transfer.json');assert sha(P/(tag+'.tar.gz'))==transfer['guest_sha256']==transfer['local_sha256']
 with tarfile.open(P/(tag+'.tar.gz')) as t:
  for m in t.getmembers():
   if m.isfile():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==sha(P/'raw'/m.name)
 blocks=lines(q/'blocks.jsonl');assert len(blocks)==20
 vals={k:[] for k in keys};counts={'direct_calls':0,'proxy_calls':0,'allow_records':0,'caller_responses':0,'allow_evidence_bytes':0}
 for i,b in enumerate(blocks):
  order='AB' if i%2==0 else 'BA';assert b['order']==order and b['block_index']==i
  for arm,pos in [('direct_stdio',0 if order=='AB' else 1),('proxy_enforce_allow',1 if order=='AB' else 0)]:
   session=q/'sessions'/f'block_{i:02}_{order}'/f'{pos}_{arm}'
   requests=lines(session/'caller_requests.ndjson');responses=lines(session/'caller_responses.ndjson');up=lines(session/'upstream_raw.jsonl')
   calls=[m for m in up if m.get('method')=='tools/call'];sent=[m for m in requests if m.get('method')=='tools/call']
   assert len(calls)==len(sent)==20 and calls==sent
   assert [m['id'] for m in responses]==[1,2,*range(101,121)];counts['caller_responses']+=len(responses)
   assert all(m.get('result')=={'content':[{'type':'text','text':'forwarded-ok'}],'isError':False} for m in responses[2:])
   counts['direct_calls' if arm=='direct_stdio' else 'proxy_calls']+=20
   assert len(b[arm]['in_session_call_rtts_ms'])==20
   if arm=='proxy_enforce_allow':
    decisions=lines(session/'decisions.ndjson');allow=[m for m in decisions if m.get('schema')=='assay.enforcement_decision.v0'];assert len(allow)==20 and all(m['decision']=='allow' and m['reason']=='allow' for m in allow)
    counts['allow_records']+=len(allow);counts['allow_evidence_bytes']+=(session/'decisions.ndjson').stat().st_size
  a=b['direct_stdio'];z=b['proxy_enforce_allow']
  vals['startup_ms'].append(z['startup_ms']-a['startup_ms'])
  vals['in_session_call_median_ms'].append(statistics.median(z['in_session_call_rtts_ms'])-statistics.median(a['in_session_call_rtts_ms']))
  vals['in_session_call_total_ms'].append(sum(z['in_session_call_rtts_ms'])-sum(a['in_session_call_rtts_ms']))
  vals['closure_flush_ms'].append(z['closure_flush_ms']-a['closure_flush_ms'])
  vals['evidence_bytes_per_session'].append(z['evidence_bytes']-a['evidence_bytes'])
 deny=q/'sessions/deny_check';up=lines(deny/'upstream_raw.jsonl');assert any(m.get('method')=='initialize' for m in up) and any(m.get('method')=='tools/list' for m in up);assert not any(m.get('method')=='tools/call' for m in up)
 resp=lines(deny/'caller_responses.ndjson');assert len(resp)==3;err=resp[-1]['error'];assert err['code']==-31999 and err['data']=={'origin':'assay-proxy','reason':'no_declared_allowance'};counts['caller_responses']+=len(resp)
 dd=lines(deny/'decisions.ndjson');assert len(dd)==1 and dd[0]['decision']=='deny' and dd[0]['fail_closed'] is True
 do=lines(deny/'denied_observations.ndjson');assert len(do)==1;raw=(deny/'caller_responses.ndjson').read_bytes().splitlines()[-1];assert do[0]['caller_visible_response_digest']=='sha256:'+hashlib.sha256(raw).hexdigest()
 metrics={};summary=json.loads((q/'summary.json').read_text())
 for offset,k in enumerate(keys):
  samples=vals[k];rng=random.Random(24942026+offset)
  # Implement the documented percentile bootstrap independently from harness.
  draws=sorted(statistics.median([samples[math.floor(rng.random()*20)] for _ in range(20)]) for _ in range(2000))
  estimate=statistics.median(samples);ci=[draws[50],draws[1949]]
  reported=summary['paired_block_metrics'][k]
  # Arm/RTT values are serialized rounded to 6 decimals. Bound double-rounding discrepancy.
  assert abs(estimate-reported['median_paired_delta'])<=0.000002,(n,k,estimate,reported)
  assert all(abs(x-y)<=0.000003 for x,y in zip(ci,reported['bootstrap_95_ci'])),(n,k,ci,reported)
  metrics[k]={'median':estimate,'bootstrap_95_ci':ci,'reported_median':reported['median_paired_delta'],'AB_median':statistics.median(samples[::2]),'BA_median':statistics.median(samples[1::2])}
 results.append({'run':n,'counts':counts,'metrics':metrics})
output={'source_sha':source['sha'],'manifest_files_verified':len(manifest),'plan_sha256':sha(P/'PLAN.json'),'result_sha256':sha(P/'RESULT.md'),'runs':results,'ranges':{k:[min(r['metrics'][k]['median'] for r in results),max(r['metrics'][k]['median'] for r in results)] for k in keys},'rounding_tolerance_ms':0.000003}
(P/'independent-review-recount.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'verified_files':len(manifest),'counts':[r['counts'] for r in results],'ranges':output['ranges']},indent=2))
