"""One-use coordinator: unchanged pinned harness; retained attempts, no retries."""
import datetime, hashlib, json, subprocess, time, tarfile, os, shutil
from pathlib import Path
P=Path(__file__).resolve().parent
VM='assay-bpf-runner'
ROOT='/home/ubuntu/assay-2494-proxy-cost'
SRC=ROOT+'/src-d4da91b0a0a5'
OUT=ROOT+'/repeatability-2026-10-18'
MAN=json.loads((P/'source-manifest-d4da91b0a0a5.json').read_text())
BINARY='787403002c677892593c5bafe89ebe183cb1516e959c5feac1ae72249882960c'
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,obj):
 with (P/name).open('x') as f: json.dump(obj,f,indent=2);f.write('\n')
def remote(args,timeout=30):
 return subprocess.run(['multipass','exec',VM,'--',*args],capture_output=True,timeout=timeout)
def observe(name):
 code="""import pathlib,hashlib,json,os,platform,shutil
src=pathlib.Path(%r)
files=%r
processes=[]
for p in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  n=(p/'comm').read_text().strip()
  if n in ['Runner.Worker','cargo','rustc','clippy-driver','assay-mcp-serve','assay-mcp-server']: processes.append({'pid':int(p.name),'name':n})
 except (FileNotFoundError,PermissionError,ProcessLookupError): pass
print(json.dumps({'files':{f:hashlib.sha256((src/f).read_bytes()).hexdigest() for f in files},'binary':hashlib.sha256(pathlib.Path(%r).read_bytes()).hexdigest(),'kernel':platform.release(),'python':platform.python_version(),'machine':platform.machine(),'loadavg':os.getloadavg(),'disk_free':shutil.disk_usage(src).free,'meminfo':pathlib.Path('/proc/meminfo').read_text(),'conflicting_processes':processes}))
"""%(SRC,list(MAN['files']),ROOT+'/assay-mcp-server')
 host={'observed_at':stamp(),'loadavg':os.getloadavg(),'disk_free':shutil.disk_usage(P).free,'memory_pressure':subprocess.run(['memory_pressure','-Q'],capture_output=True,text=True,timeout=10).stdout,'swap':subprocess.run(['sysctl','vm.swapusage'],capture_output=True,text=True,timeout=10).stdout}
 save('host-'+name,host)
 assert host['disk_free']>=5_000_000_000,'host disk floor'
 r=remote(['python3','-c',code]);r.check_returncode();d=json.loads(r.stdout);d['observed_at']=stamp();save(name,d)
 assert d['files']==MAN['files'] and d['binary']==BINARY,'input drift'
 assert not d['conflicting_processes'],'busy guest'
 assert d['disk_free']>1024**3,'guest disk capacity'
 return d
if __name__=='__main__':
 assert (P/'PLAN.json').exists(),'freeze plan first'
 r=remote(['mkdir',OUT]);r.check_returncode()
 for n in range(1,4):
  observe(f'run-{n:02d}-before.json')
  args=['timeout','--kill-after=5','150','python3',SRC+'/docs/experiments/mcp-proxy-cost-2026-10/proxy_cost_pilot.py','--mcp-binary',ROOT+'/assay-mcp-server','--expected-binary-sha256',BINARY,'--out-dir',OUT+f'/run-{n:02d}','--blocks','20','--calls-per-session','20','--timeout-seconds','30','--bootstrap-resamples','2000']
  start=stamp()
  try:
   r=remote(args,timeout=165)
  except subprocess.TimeoutExpired as e:
   save(f'run-{n:02d}-supervisor.json',{'started_at':start,'ended_at':stamp(),'argv':args,'error':'multipass_timeout','stdout':(e.stdout or b'').decode(errors='replace'),'stderr':(e.stderr or b'').decode(errors='replace')})
   raise
  save(f'run-{n:02d}-supervisor.json',{'started_at':start,'ended_at':stamp(),'argv':args,'exit_code':r.returncode})
  (P/f'run-{n:02d}.stdout').write_bytes(r.stdout);(P/f'run-{n:02d}.stderr').write_bytes(r.stderr)
  observe(f'run-{n:02d}-after.json')
  packed=remote(['tar','-czf',OUT+f'/run-{n:02d}.tar.gz','-C',OUT,f'run-{n:02d}']);packed.check_returncode()
  subprocess.run(['multipass','transfer',VM+':'+OUT+f'/run-{n:02d}.tar.gz',str(P/f'run-{n:02d}.tar.gz')],check=True,timeout=30)
  remote_hash=remote(['sha256sum',OUT+f'/run-{n:02d}.tar.gz']);remote_hash.check_returncode()
  local_hash=hashlib.sha256((P/f'run-{n:02d}.tar.gz').read_bytes()).hexdigest()
  save(f'run-{n:02d}-transfer.json',{'guest_sha256':remote_hash.stdout.decode().split()[0],'local_sha256':local_hash})
  assert remote_hash.stdout.decode().split()[0]==local_hash,'transfer mismatch'
  with tarfile.open(P/f'run-{n:02d}.tar.gz') as t:t.extractall(P/'raw',filter='data')
  print('run',n,'exit',r.returncode,flush=True)
  r.check_returncode()
  if n<3: time.sleep(30)
 print('THREE ATTEMPTS COMPLETE',flush=True)
