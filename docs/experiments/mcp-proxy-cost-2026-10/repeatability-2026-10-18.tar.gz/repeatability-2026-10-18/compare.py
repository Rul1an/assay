"""Descriptive recount from retained arm measurements, never a regression gate."""
import hashlib,json,random,statistics
from pathlib import Path
P=Path(__file__).resolve().parent
keys=['startup_ms','in_session_call_median_ms','in_session_call_total_ms','closure_flush_ms','evidence_bytes_per_session']
result={'source_sha':'d4da91b0a0a5ece52683f28e0915b933bce0d4ad','runs':[],'non_claims':['Not a stable/unstable pass threshold','Not three independent environments','Timings trusted as recorded by harness; not recoverable from wire bytes']}
for n in range(1,4):
 d=P/'raw'/f'run-{n:02d}';s=json.loads((d/'summary.json').read_text());b=[json.loads(x) for x in (d/'blocks.jsonl').read_text().splitlines()]
 assert s['execution_valid'] and s['valid_blocks']==20 and len(b)==20
 row={'run':n,'started_at':s['started_at'],'completed_at':s['completed_at'],'metrics':{},'calls_direct':sum(x['direct_stdio']['upstream_tools_call_count'] for x in b),'calls_proxy':sum(x['proxy_enforce_allow']['upstream_tools_call_count'] for x in b),'allow_records':sum(x['proxy_enforce_allow']['decision_evidence_records'] for x in b),'deny_status':s['deny_check_status']}
 assert row['calls_direct']==row['calls_proxy']==row['allow_records']==400
 for off,key in enumerate(keys):
  field='evidence_bytes' if key=='evidence_bytes_per_session' else key
  vals=[round(x['proxy_enforce_allow'][field]-x['direct_stdio'][field],6) for x in b]
  rng=random.Random(24942026+off);boots=sorted(statistics.median(rng.choices(vals,k=20)) for _ in range(2000))
  med=round(statistics.median(vals),6);ci=[round(boots[50],6),round(boots[1949],6)]
  assert med==s['paired_block_metrics'][key]['median_paired_delta'] and ci==s['paired_block_metrics'][key]['bootstrap_95_ci']
  row['metrics'][key]={'median':med,'within_run_bootstrap_95_ci':ci,'AB_median':round(statistics.median(v for x,v in zip(b,vals) if x['order']=='AB'),6),'BA_median':round(statistics.median(v for x,v in zip(b,vals) if x['order']=='BA'),6)}
 result['runs'].append(row)
result['descriptive_between_run_ranges']={k:[min(r['metrics'][k]['median'] for r in result['runs']),max(r['metrics'][k]['median'] for r in result['runs'])] for k in keys}
with (P/'comparison.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
