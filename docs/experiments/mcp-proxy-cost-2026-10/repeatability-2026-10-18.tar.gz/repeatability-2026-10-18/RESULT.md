# MCP-proxykosten: drie herhaalruns
#2494 — bron d4da91b0a0a5ece52683f28e0915b933bce0d4ad; gemerged via PR3368.

Drie vooraf vastgelegde pogingen afgerond, zonder retries of weggegooide runs. Zelfde Linux VM, v6.14.1 ARM64 binary, negen bronbestanden, 20 AB/BA-blokken ×20 calls per arm. Pauze30s na overdracht. Geen warmup, reboot of cacheflush; cachetoestand niet gemeten.

| Metriek (proxy minus direct) | Run1 | Run2 | Run3 |
|---|---:|---:|---:|
| Opstart ms | 2.011964 [1.161544, 3.303614] | 2.212194 [1.535296, 3.213385] | 3.093113 [1.113628, 4.251617] |
| Mediaan call ms | 0.562314 [0.507991, 0.589512] | 0.564772 [0.528720, 0.597263] | 0.564877 [0.519481, 0.582075] |
| Totaal20 calls ms | 11.537595 [10.768759, 11.856889] | 11.955826 [11.061784, 12.720954] | 11.472682 [10.591303, 11.831180] |

Haken: bestaande bootstrap95%-intervallen binnen elke run, geen interval over drie runs. De call-runmedianen liggen hier dicht bij elkaar (0,562314–0,564877ms); startup varieert meer (2,011964–3,093113ms). Dit is een beschrijvende waarneming binnen circa67s op één gedeelde VM, geen bewijs voor stabiliteit over dagen, hosts of productieworkloads. Geen CI-drempel of equivalentietoets afgeleid.

Per run400 directe calls,400 proxycalls,400allow-records en een geslaagde denycontrole. Evidence21500bytes per sessie,1075bytes/call voor deze vaste input. Geen p99/SLA, netwerk- of modelclaim.

Closure-medianen -1,968/-1,774/-1,778ms zijn geen speedupclaim (verschillende teardownpaden). RSS wordt alleen als maximum van één proces bewaard en is niet vergelijkbaar als totale procesboom.

Bron- en binaryhashes vóór/na elke run gelijk; archiefhashes op VM en Mac gelijk. Host/guest-capaciteit en belasting vóór/na vastgelegd; geen continue isolatiecontrole. De 740 behouden bron- en bewijsbestanden staan in PACKAGE-MANIFEST.json. Dit rapport en de latere review staan daarbuiten en krijgen afzonderlijke hashes.

Reproduceren: uitvoercommando per run in run-XX-supervisor.json; exact bronarchief source-d4da91b0a0a5.tar met manifest, binaryprovenance en eerdere attestation-verificatie bijgevoegd. Nieuwe uitvoering vereist nieuwe exclusieve outputmappen. compare.py herberekent deltas uit armvelden in blocks.jsonl; klokmetingen zijn niet uit wirebytes opnieuw afleidbaar.

Claude Code Desktop gaf read-only methodeadvies (CLAUDE-METHOD.md); onafhankelijke recipient/recountreview is afzonderlijk vastgelegd in independent-review.md (inhoudelijke herberekening akkoord). Geen productiecode, benchmarkcode of CI gewijzigd. Issue blijft open.
