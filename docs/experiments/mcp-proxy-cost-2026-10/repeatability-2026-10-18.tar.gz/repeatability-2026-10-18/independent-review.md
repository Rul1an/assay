# Independent recipient review — READY

Subject: retained three-attempt #2494 package only. Source declared d4da91b0a0a5ece52683f28e0915b933bce0d4ad, source archive and nine-file manifest included. Actual reviewer Codex /root/2497_final_review (codex/2497_final_review), independent of experiment implementation, follow-up execution and governing method/plan. No design/code/plan authorship. Publisher/coordinator is separate; reviewer identity and independence are declared, not independently authenticated.

## Recipient checks

Independently hashed all740 listed files; all match PACKAGE-MANIFEST.json. Verified PLAN.sha256, executor digest bound by PLAN, all nine source members against both source archive and extracted tree, each transfer archive against guest/local hash receipt, and all archived run members against received raw files. Six pre/post source and binary hash records agree; disk floors satisfied and snapshots list no conflicting guest processes. All three supervisor receipts exit0; declared freeze precedes first invocation; inter-run gaps exceed30s. Read execute.py without executing it: fixed3attempt loop, exclusive outputs, no retry, check_returncode after retaining attempt and transfer,30s pause. These retained records support adherence but do not independently authenticate capture time, provisioning or absence of unrecorded executions.

Raw recount per run:400 direct upstream tools/call,400 proxy upstream tools/call,400 allow decisions,883 caller responses,430000allow evidence bytes. Across three runs:1200+1200calls,1200allow records,2649responses,1290000allow evidence bytes. Each run has20 alternating AB/BA blocks,20calls per arm/session. Caller/upstream call objects and response ID sequences checked across all120 timed sessions. Three deny sessions each have positive init/discovery, zero upstream tools/call, one deny decision, one denied observation and matching caller-visible response digest. No missing attempt or failed attempt is visible in the supplied three-attempt package.

## Independently derived timing comparison

Used arm startup/closure fields and individual RTT lists in blocks.jsonl, never precomputed paired deltas or summary values as input. Reimplemented median and seeded percentile bootstrap (2000resamples,20block observations,seed24942026+metric offset) independently without importing supplied harness or compare.py. Bootstrap draw implementation uses uniform random indices; percentile positions50/1949 reproduce documented algorithm. Checked outputs against summaries only after calculation.

| Proxy-minus-direct median ms | Run1 | Run2 | Run3 | Descriptive range |
|---|---:|---:|---:|---:|
| Startup |2.0119645|2.2121945|3.0931130|2.0119645–3.0931130|
| Median call RTT |0.56231450|0.56477325|0.56487675|0.56231450–0.56487675|
| Total20call RTT |11.5375950|11.9558260|11.4726815|11.4726815–11.9558260|

All reported medians and within-run bootstrap endpoints agree within0.000003ms, accounting for six-decimal serialization and intermediate rounding. In particular run2 median-of-call-medians recomputed from serialized RTTs is0.56477325ms versus published0.564772ms; this tiny precision loss does not change the bounded conclusion. Detailed independent values/CIs and order-group medians are in independent-review-recount.json. Each evidence delta is21500bytes/session,1075bytes/call for the fixed input. Negative closure values are descriptive teardown measurements, not speedup evidence.

## Result review and finding

READY for the bounded descriptive conclusions: call-run medians are close within this roughly67second span on one shared VM; startup varies more. No pooling, between-run confidence interval, equivalence threshold, production stability, cross-host/day generalization, p99/SLA or model/network overhead claim is supported. Cache warmth and continuous isolation remain unknown. Host snapshots include substantial load/swap, reinforcing the stated shared-host restriction. Timing-clock samples cannot be independently reobserved from wire bytes; this review checks computation from retained timing records. RSS remains non-comparable single-process high-water, not aggregate tree memory. Binary provenance/attestation are supplied records, not newly authenticated by reviewer.

F1 [P3, resolved]: original RESULT.md said all files were in PACKAGE-MANIFEST.json. Coordinator preserved it as RESULT.pre-review.md and corrected the final report to distinguish the740listed source/evidence files from the separately hashed report/review. Independently inspected the two-paragraph delta: only manifest-scope wording and review-status reference changed; measurements unchanged. No remaining actionable finding. Reviewer did not edit inputs or RESULT. Original RESULT SHA256: 87c37c5e30b4c5a8aab0925628b7406518ada22c212ada1da3bd13f89cc36e39.

## Bound artifacts and actions

- PLAN.json SHA256: 5427038ba803c0cf4b770f49ef0985f9015fbff6db36466bbae19a765813af4e
- PACKAGE-MANIFEST.json SHA256: b93eb4c1c5f959b082f9e790fe862f0db917a0597e83231467c18d056956f6bb
- RESULT.md reviewed SHA256: db31dea787bdf3158ff5858f5c6114b51e1080fdf2db3f4f268717432fb17c7d
- Independent recount script SHA256: f6340d394b9bb12e35773342f2b56740f98ee5e7ee5e906d8c71af7ff171c98a
- Independent recount output SHA256: 7f477bbf0823a1ddde93d570f83839e65cbd5ad183593f7c36b6b61aa51d1d87

Only package-local Python read/hash/recount executed. No benchmark, builds, network, full discovery, input edits or normative method authoring. Review script and output are independently authored derivatives, outside the frozen manifest. READY is recipient/numerical review, not automatic publication, issue closure, hosted proof or a general performance endorsement.

Final RESULT delta inspected and bound to SHA256 db31dea787bdf3158ff5858f5c6114b51e1080fdf2db3f4f268717432fb17c7d. Recount output retains the original pre-review RESULT hash as historical input binding; measurement records are unchanged.
